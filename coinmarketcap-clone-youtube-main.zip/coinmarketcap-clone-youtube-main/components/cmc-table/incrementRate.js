// import ChevronDown from "../../assets/svg/chevronDown"
// import ChevronUp from "../../assets/svg/chevronUp"

// const RateRow = ({ isIncrement, rate }) => {
//     return <div className="flex">
//         {isIncrement ? <ChevronUp /> : <ChevronDown />}
//         <p>{rate}</p>
//     </div>
// }

// export default RateRow
