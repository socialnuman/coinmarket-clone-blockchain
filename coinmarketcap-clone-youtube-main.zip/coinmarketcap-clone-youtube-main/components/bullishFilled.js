import ChevronUp from "../assets/svg/chevronUp"

const BullishFilled = () => {
    return <div>
        <ChevronUp />
        <small>Bullish</small>
    </div>
}

export default BullishFilled