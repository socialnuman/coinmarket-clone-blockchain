// import ChevronDown from "../../assets/svg/chevronDown"
// import Info from "../../assets/svg/info"

// const CMCtableTitle = () => {
//     return <tbody>
//         <tr>
//             <th></th>
//             <th><b>#</b><ChevronDown /></th>
//             <th>Name</th>
//             <th>Price</th>
//             <th>24h %</th>
//             <th>7d %</th>
//             <th><div className="flex"><p>Market Cap</p> <Info /></div></th>
//             <th><div className="flex"><p>Volume(24h)</p> <Info /></div></th>
//             <th><div className="flex"><p>Circulating Supply</p> <Info /></div></th>
//             <th>Last 7 days</th>
//         </tr>
//     </tbody>
// }

// export default CMCtableTitle
